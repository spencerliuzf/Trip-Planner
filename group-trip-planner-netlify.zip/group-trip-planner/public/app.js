(() => {
  const $ = s => document.querySelector(s);
  const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const CATS = {
    flight:{n:"Flights",c:"#0f6b5c"}, stay:{n:"Stay",c:"#f2b632"}, transport:{n:"Local transport",c:"#5b7fd6"},
    food:{n:"Food & drinks",c:"#d9734a"}, activity:{n:"Activities",c:"#9b5fc0"}, other:{n:"Other",c:"#8a9a94"}
  };
  const ls = {
    get(k){ try { return localStorage.getItem(k) || ""; } catch(e){ return ""; } },
    set(k,v){ try { localStorage.setItem(k,v); } catch(e){} }
  };
  let trip = {name:"", destination:"", start:"", end:"", currency:"CAD", budgetPP:0, crew:[]};
  let items = [], days = [], filter = "all", loaded = false;
  let me = ls.get("trip-me"), code = ls.get("trip-code");

  // ---------- API ----------
  async function api(method, path, body){
    const r = await fetch("/api/" + path, {
      method, headers: {"content-type":"application/json", "x-trip-code": code},
      body: body ? JSON.stringify(body) : undefined
    });
    if (r.status === 401) { showLock(code ? "Wrong code. Try again." : ""); throw new Error("locked"); }
    if (!r.ok) throw new Error("http " + r.status);
    return r.status === 204 ? null : r.json();
  }
  const status = m => { $("#status").textContent = m || ""; };
  async function run(method, path, body){
    try { const out = await api(method, path, body); status(""); await refresh(); return out; }
    catch(e){ if (e.message !== "locked") status("Could not save. Check your connection and try again."); }
  }
  async function refresh(){
    try {
      const s = await api("GET", "state");
      trip = {...trip, ...(s.trip || {})}; trip.crew = trip.crew || [];
      items = s.items || []; days = s.days || []; loaded = true;
      $("#lock").hidden = true; $("#app").hidden = false;
      renderAll();
    } catch(e){ if (e.message !== "locked") status("Could not load the trip. Retrying…"); }
  }
  function showLock(msg){ $("#app").hidden = true; $("#lock").hidden = false; $("#lockMsg").textContent = msg || ""; }
  $("#lock").onsubmit = e => { e.preventDefault(); code = $("#codeIn").value.trim(); ls.set("trip-code", code); refresh(); };

  // ---------- helpers ----------
  const N = () => Math.max(trip.crew.length, 1);
  const money = (v, dp) => {
    const cur = trip.currency || "CAD";
    try { return new Intl.NumberFormat(undefined,{style:"currency",currency:cur,maximumFractionDigits:dp??0,minimumFractionDigits:dp??0}).format(v||0); }
    catch(e){ return cur + " " + Math.round(v||0); }
  };
  const total = it => (+it.amount||0) * (it.basis === "person" ? N() : 1);
  const fmtDate = d => d ? new Date(d+"T12:00:00").toLocaleDateString(undefined,{month:"short",day:"numeric"}) : "";

  // ---------- tabs / filters ----------
  document.querySelectorAll(".tabs button").forEach(b => b.onclick = () => {
    document.querySelectorAll(".tabs button").forEach(x => x.setAttribute("aria-selected", x===b));
    ["costs","plan","settle","setup"].forEach(t => $("#p-"+t).hidden = t !== b.dataset.tab);
  });
  document.querySelectorAll("#filters .chip").forEach(b => b.onclick = () => {
    filter = b.dataset.f;
    document.querySelectorAll("#filters .chip").forEach(x => x.setAttribute("aria-pressed", x===b));
    renderItems();
  });

  // ---------- price-check links ----------
  function renderPriceLinks(){
    const d = trip.destination, q = encodeURIComponent(d || ""), n = N();
    const ci = trip.start || "", co = trip.end || "";
    const cat = $("#iCat").value;
    let links = [];
    if (!d) { $("#priceLinks").innerHTML = `Set a destination in Trip setup to get price-check links here.`; return; }
    if (cat === "flight") links = [
      ["Google Flights", `https://www.google.com/travel/flights?q=${encodeURIComponent("Flights to " + d + (ci ? " on " + ci : "") + (co ? " returning " + co : ""))}`],
      ["Skyscanner", `https://www.skyscanner.ca/`]];
    else if (cat === "stay") links = [
      ["Airbnb", `https://www.airbnb.ca/s/${q}/homes?adults=${n}${ci?`&checkin=${ci}`:""}${co?`&checkout=${co}`:""}`],
      ["Booking.com", `https://www.booking.com/searchresults.html?ss=${q}&group_adults=${n}${ci?`&checkin=${ci}`:""}${co?`&checkout=${co}`:""}`],
      ["Google Hotels", `https://www.google.com/travel/hotels?q=${encodeURIComponent("hotels in " + d)}`]];
    else if (cat === "activity") links = [
      ["GetYourGuide", `https://www.getyourguide.com/s/?q=${q}`],
      ["Tripadvisor", `https://www.tripadvisor.ca/Search?q=${q}`]];
    else if (cat === "transport") links = [
      ["Rome2Rio", `https://www.rome2rio.com/s/${q}`],
      ["Car rentals", `https://www.google.com/search?q=${encodeURIComponent("car rental " + d)}`]];
    else links = [["Search prices", `https://www.google.com/search?q=${encodeURIComponent(($("#iTitle").value || "cost") + " " + d + " price")}`]];
    $("#priceLinks").innerHTML = `<span class="hint">Check real prices:</span> ` +
      links.map(([t,u]) => `<a href="${esc(u)}" target="_blank" rel="noopener">${esc(t)} ↗</a>`).join("");
  }
  $("#iCat").onchange = renderPriceLinks;

  // ---------- render ----------
  function renderHeader(){
    $("#tripName").textContent = trip.name || "Your next trip";
    document.title = (trip.name ? trip.name + " · " : "") + "Group Trip Planner";
    $("#tripDest").textContent = trip.destination || "set a destination";
    let dt = "Dates not set";
    if (trip.start) {
      dt = fmtDate(trip.start) + (trip.end ? " – " + fmtDate(trip.end) : "");
      if (trip.end) { const n = Math.round((new Date(trip.end) - new Date(trip.start))/864e5); if (n>0) dt += ` · ${n} night${n>1?"s":""}`; }
    }
    $("#tripDates").textContent = dt;
    $("#tripCrew").textContent = `${trip.crew.length} traveller${trip.crew.length===1?"":"s"}`;
    const crewOpts = trip.crew.map(c => `<option value="${esc(c)}">${esc(c)}</option>`).join("");
    const keepPaid = $("#iPaid").value;
    $("#iPaid").innerHTML = `<option value="">Nobody yet</option>` + crewOpts; $("#iPaid").value = keepPaid;
    $("#meSel").innerHTML = `<option value="">— pick your name —</option>` + crewOpts;
    if (!trip.crew.includes(me)) me = "";
    $("#meSel").value = me;
    $("#meHint").textContent = me ? "" : (trip.crew.length ? "Pick your name to vote." : "Add the crew in Trip setup first.");
    $("#crewList").innerHTML = trip.crew.length
      ? trip.crew.map((c,i) => `<span>${esc(c)}<button type="button" aria-label="Remove ${esc(c)}" data-rm="${i}">×</button></span>`).join("")
      : `<span class="hint" style="border:0;background:none;padding:0">No one yet.</span>`;
    $("#crewList").querySelectorAll("[data-rm]").forEach(b => b.onclick = () => { const c = trip.crew.slice(); c.splice(+b.dataset.rm,1); saveTrip({crew:c}); });
    if (!$("#tripForm").contains(document.activeElement)) {
      $("#tName").value = trip.name||""; $("#tDest").value = trip.destination||"";
      $("#tStart").value = trip.start||""; $("#tEnd").value = trip.end||"";
      $("#tCur").value = trip.currency||"CAD"; $("#tBudget").value = trip.budgetPP||"";
    }
  }

  function renderSummary(){
    let all=0, booked=0, ideas=0, nb=0, ni=0; const byCat = {};
    items.forEach(it => { const t = total(it); all += t; byCat[it.category] = (byCat[it.category]||0)+t;
      if (it.status==="booked"){ booked+=t; nb++; } else { ideas+=t; ni++; } });
    const pp = all / N();
    $("#ppBig").textContent = money(pp);
    $("#ppSub").textContent = trip.crew.length ? `split ${trip.crew.length} ways` : "add the crew to split";
    $("#kTotal").textContent = money(all);
    $("#kBooked").textContent = money(booked); $("#kBookedS").textContent = `${nb} item${nb===1?"":"s"}`;
    $("#kIdeas").textContent = money(ideas); $("#kIdeasS").textContent = `${ni} item${ni===1?"":"s"}`;
    if (trip.budgetPP > 0) {
      const r = pp / trip.budgetPP;
      $("#kBudget").textContent = money(trip.budgetPP);
      $("#kMeter").style.width = Math.min(r*100,100)+"%";
      $("#kMeter").classList.toggle("over", r>1);
      $("#kBudgetS").textContent = r>1 ? `${money(pp-trip.budgetPP)} over` : `${money(trip.budgetPP-pp)} left`;
    } else { $("#kBudget").textContent = "—"; $("#kMeter").style.width="0%"; $("#kBudgetS").textContent = "Set it in Trip setup"; }
    const cats = Object.keys(CATS).filter(k => byCat[k] > 0);
    $("#catbar").innerHTML = all ? cats.map(k => `<i style="width:${byCat[k]/all*100}%;background:${CATS[k].c}" title="${CATS[k].n}"></i>`).join("") : "";
    $("#legend").innerHTML = all ? cats.map(k => `<span><i style="background:${CATS[k].c}"></i>${CATS[k].n} <span class="mono">${money(byCat[k]/N())}</span>/pp</span>`).join("") : `<span>Add costs to see the breakdown.</span>`;
  }

  function renderItems(){
    if (!loaded) return;
    let list = items.slice();
    if (filter==="idea"||filter==="booked") list = list.filter(i => i.status===filter);
    if (filter==="votes") list.sort((a,b) => (b.votes||[]).length - (a.votes||[]).length);
    else list.sort((a,b) => (Object.keys(CATS).indexOf(a.category) - Object.keys(CATS).indexOf(b.category)) || ((b.created||0)-(a.created||0)));
    if (!list.length) { $("#items").innerHTML = `<div class="empty">${items.length ? "Nothing in this filter." : "No costs yet. Add flights, a place to stay, or an activity above."}</div>`; return; }
    $("#items").innerHTML = list.map(it => {
      const cat = CATS[it.category] || CATS.other, v = it.votes||[], mine = me && v.includes(me), t = total(it);
      return `<div class="item" data-id="${esc(it.id)}">
        <i class="dot" style="background:${cat.c}"></i>
        <div class="t">${esc(it.title)}</div>
        <div class="price">${money(t)}<small>${money(t/N())} /pp</small></div>
        <div class="meta">
          <span class="pill ${it.status==="booked"?"booked":"idea"}">${it.status==="booked"?"Booked":"Idea"}</span>
          <span>${cat.n}</span>
          ${it.basis==="person" ? `<span class="mono">${money(+it.amount,2)} each</span>` : ""}
          ${it.paidBy ? `<span>Paid by ${esc(it.paidBy)}</span>` : ""}
          ${it.url && /^https?:\/\//i.test(it.url) ? `<a href="${esc(it.url)}" target="_blank" rel="noopener">Link</a>` : ""}
          <button class="vote ${mine?"on":""}" data-act="vote" ${!me?"disabled":""} aria-label="Vote">▲ ${v.length}</button>
          <button class="btn ghost" data-act="toggle">${it.status==="booked"?"Mark idea":"Mark booked"}</button>
          <button class="btn ghost" data-act="del">Delete</button>
        </div></div>`;
    }).join("");
  }

  function renderDays(){
    if (!loaded) return;
    if (!days.length) { $("#days").innerHTML = `<div class="empty">No plans yet. Add the first day above.</div>`; return; }
    const g = {};
    days.forEach(d => (g[d.date] = g[d.date] || []).push(d));
    $("#days").innerHTML = Object.keys(g).sort().map(k => {
      const x = new Date(k+"T12:00:00");
      let dn = "";
      if (trip.start) { const n = Math.round((x - new Date(trip.start+"T12:00:00"))/864e5)+1; if (n>0) dn = "Day "+n; }
      const rows = g[k].sort((a,b)=>(a.time||"99").localeCompare(b.time||"99"));
      return `<div class="day"><div class="d">${x.toLocaleDateString(undefined,{month:"short",day:"numeric"})}<small>${dn || x.toLocaleDateString(undefined,{weekday:"short"})}</small></div>
        <ul>${rows.map(r => `<li><span class="tm">${esc(r.time||"—")}</span><span class="tx">${esc(r.text)}</span><button class="btn ghost" data-del-day="${esc(r.id)}" aria-label="Remove">×</button></li>`).join("")}</ul></div>`;
    }).join("");
    $("#days").querySelectorAll("[data-del-day]").forEach(b => b.onclick = () => run("DELETE", "days/" + encodeURIComponent(b.dataset.delDay)));
  }

  function renderSettle(){
    const crew = trip.crew, paid = {}, share = {};
    crew.forEach(c => { paid[c]=0; share[c]=0; });
    let any = false;
    items.filter(i => i.status==="booked" && i.paidBy && crew.includes(i.paidBy)).forEach(i => {
      any = true; const t = total(i); paid[i.paidBy] += t; crew.forEach(c => share[c] += t/crew.length);
    });
    $("#balBody").innerHTML = crew.length ? crew.map(c => { const b = paid[c]-share[c];
      return `<tr><td>${esc(c)}</td><td class="n">${money(paid[c],2)}</td><td class="n">${money(share[c],2)}</td><td class="n ${b>0.005?"pos":b<-0.005?"neg":""}">${b>0?"+":""}${money(b,2)}</td></tr>`; }).join("")
      : `<tr><td colspan="4" class="hint">Add the crew in Trip setup.</td></tr>`;
    if (!any) { $("#transfers").innerHTML = `<div class="empty">Nothing to settle yet. Mark a cost as booked and set who paid.</div>`; return; }
    const cred = [], debt = [];
    crew.forEach(c => { const b = Math.round((paid[c]-share[c])*100)/100; if (b>0) cred.push([c,b]); else if (b<0) debt.push([c,-b]); });
    cred.sort((a,b)=>b[1]-a[1]); debt.sort((a,b)=>b[1]-a[1]);
    const out = []; let i=0, j=0;
    while (i<debt.length && j<cred.length) {
      const amt = Math.min(debt[i][1], cred[j][1]);
      if (amt >= 0.01) out.push(`<div class="transfer"><b>${esc(debt[i][0])}</b> pays <b>${esc(cred[j][0])}</b><span style="flex:1"></span><span class="mono" style="font-weight:600">${money(amt,2)}</span></div>`);
      debt[i][1]-=amt; cred[j][1]-=amt;
      if (debt[i][1] < 0.01) i++;
      if (cred[j][1] < 0.01) j++;
    }
    $("#transfers").innerHTML = out.join("") || `<div class="empty">Everyone is even.</div>`;
  }

  function renderAll(){ renderHeader(); renderSummary(); renderItems(); renderDays(); renderSettle(); renderPriceLinks(); }

  // ---------- actions ----------
  function saveTrip(patch){ trip = {...trip, ...patch}; renderAll(); return run("PUT", "trip", trip); }
  $("#meSel").onchange = e => { me = e.target.value; ls.set("trip-me", me); renderAll(); };
  $("#tripForm").onsubmit = e => { e.preventDefault();
    saveTrip({name:$("#tName").value.trim(), destination:$("#tDest").value.trim(), start:$("#tStart").value, end:$("#tEnd").value, currency:$("#tCur").value, budgetPP:+$("#tBudget").value||0});
    $("#tripMsg").textContent = "Saved"; setTimeout(()=>$("#tripMsg").textContent="",1500);
  };
  $("#crewForm").onsubmit = e => { e.preventDefault();
    const n = $("#cName").value.trim(); if (!n || trip.crew.includes(n)) return;
    $("#cName").value = ""; saveTrip({crew:[...trip.crew, n]});
  };
  $("#itemForm").onsubmit = async e => { e.preventDefault();
    const amt = parseFloat($("#iAmount").value);
    if (!$("#iTitle").value.trim() || !(amt >= 0)) return;
    $("#addBtn").disabled = true;
    await run("POST", "items", { title:$("#iTitle").value.trim(), category:$("#iCat").value, amount:amt, basis:$("#iBasis").value,
      status:$("#iStatus").value, paidBy:$("#iPaid").value, url:$("#iUrl").value.trim() });
    $("#addBtn").disabled = false;
    $("#itemForm").reset(); renderPriceLinks();
  };
  $("#items").addEventListener("click", e => {
    const b = e.target.closest("[data-act]"); if (!b) return;
    const id = b.closest(".item").dataset.id, it = items.find(x => x.id===id); if (!it) return;
    const path = "items/" + encodeURIComponent(id);
    if (b.dataset.act==="vote" && me) run("POST", path + "/vote", {name: me});
    if (b.dataset.act==="toggle") run("PATCH", path, {status: it.status==="booked"?"idea":"booked"});
    if (b.dataset.act==="del") {
      if (b.dataset.confirm) run("DELETE", path);
      else { b.dataset.confirm = "1"; b.textContent = "Tap again to delete"; setTimeout(()=>{ if(b.isConnected){ delete b.dataset.confirm; b.textContent="Delete"; } }, 3000); }
    }
  });
  $("#dayForm").onsubmit = async e => { e.preventDefault();
    const d = {date:$("#dDate").value, time:$("#dTime").value, text:$("#dText").value.trim()};
    if (!d.date || !d.text) return;
    await run("POST", "days", d);
    $("#dText").value = ""; $("#dTime").value = "";
  };

  // ---------- start + live refresh ----------
  renderAll();
  refresh();
  setInterval(() => {
    if (document.visibilityState !== "visible") return;
    const typing = document.activeElement && /INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName);
    if (!typing) refresh();
  }, 10000);
  document.addEventListener("visibilitychange", () => { if (document.visibilityState === "visible") refresh(); });
})();
