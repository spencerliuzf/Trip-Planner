# Group Trip Planner

Shared trip planner: costs, per-person split, votes, itinerary, budget, settle-up.
Data is stored in Netlify Blobs (free, no database account needed).

## Deploy (pick one)

### A. From a computer (fastest, ~3 min)
1. Install Node.js (https://nodejs.org) if you do not have it.
2. Unzip this folder. Open a terminal in it.
3. Run: `npx netlify-cli login` (a browser opens; log in to Netlify).
4. Run: `npx netlify-cli deploy --build --prod`
   - Choose "Create & configure a new project", pick a site name.
5. Open the URL it prints.

### B. With GitHub (works from a phone browser)
1. Create a new GitHub repo. Upload all files in this folder (keep the folder structure).
2. In Netlify: Add new project > Import an existing project > GitHub > pick the repo.
3. Leave the build settings as they are (netlify.toml sets them). Click Deploy.

Note: Netlify Drop (drag-and-drop) does not run the API function, so the shared data will not work with it. Use A or B.

## Make it private (recommended)
Anyone with the URL can edit the trip. To add a code:
Netlify > your site > Site configuration > Environment variables > add `TRIP_CODE` = any code.
Then redeploy (Deploys > Trigger deploy). Give the code to your friends.
